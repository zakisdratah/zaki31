# gmail_attacker
python script for hack gmail account using brute force attack
# installation
git clone https://github.com/ayoubsiray/gmail_attacker.git

# review
![screenshot from 2018-01-12 20 47 45](https://user-images.githubusercontent.com/28595515/34894595-f5ce60b6-f7d9-11e7-8ac1-5eb0180745e3.png)

![screenshot from 2018-01-12 13 34 09](https://user-images.githubusercontent.com/28595515/34877303-6b417cf8-f79d-11e7-80c2-964b08ea8f04.png)
